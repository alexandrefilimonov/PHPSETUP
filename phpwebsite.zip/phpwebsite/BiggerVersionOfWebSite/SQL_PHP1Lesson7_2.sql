﻿USE world;

CREATE TABLE IF NOT EXISTS `user` 
(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  
   `name` varchar(25) NOT NULL,
   
   `password` varchar(32) NOT NULL,
  
   `date_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=UTF8MB4 AUTO_INCREMENT=6 ;

INSERT INTO `user` (`name`, `password`, `date_creation`) VALUES

('admin', '12345', '2018-09-02 17:54:20'),

('Alex', '827ccb0eea8a706c4c34a16891f84e7b', '2018-09-02 17:54:20') 


﻿<?php
echo '<hr />';
echo 'PHP1 Lesson5:<br />';

include "configmysql.php";
$sql = "select * from images";
$res = mysqli_query($connection,$sql);

include_once "models\config.php";
$n = 3;
$s = "<ul>Chose your bouquet of flowers to purchase:<br>"; 
//$pHOTOBIG="img/pics/";
//$files = glob($pHOTOBIG."*.jpg");
//foreach($files as $jpg){

while($data = mysqli_fetch_assoc($res)){
	$s = $s . "<li><a href='".$pHOTOBIG.$data[name].".jpg.' target='_new'><img src='".$jpg."' width='90px'></a><br /></li><br>";
}

for($i=1;$i<=$n; $i++) {
}
$s = $s."</ul>";
?>
<html>
<head></head>
<body>
	<?=$s?>
</body>
</html>


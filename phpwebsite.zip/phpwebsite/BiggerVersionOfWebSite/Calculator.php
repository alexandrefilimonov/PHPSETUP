﻿<?php
$op1=(int)$_GET['op1'];
$op2=(int)$_GET['op2'];
$c=$_GET['op'];
$s=0;
//print_r($s);
if($c=="Summary") {
	$s=$op1+$op2;
}
if($c=="Substraction") {
	$s=$op1-$op2;
}
if($c=="Multiplication") {
	$s=$op1*$op2;
}
if($c=="Division") {
	if($op2!=0) {
		$s=$op1/$op2;		
	}
	else {
		$s="Делить на ноль запрещено!";
	}
}
?>
<html>
<head>
	<meta charset="UTF-8">
</head>
<body>
	<form action="Calculator.php" method="GET" >
		<table>
		<tr><td>Операнд №1:</td><td><input name="op1" type="text" autocomplete="on" /></td></tr>
		<tr><td>Действие:</td><td><select name="op">
			<option value="Summary">+ сложить</option>
			<option value="Substraction">- вычесть</option>
			<option value="Multiplication">* умножить</option>
			<option value="Division">/ разделить</option>
		</select></td></tr>
	
		<tr><td>Операнд №2:</td><td><input name="op2" type="text" autocomplete="on" /></td></tr>
		<tr><td></td><td><input type="submit" name="Send" value="Отправить сообщение"></td></tr>
		<tr><td>Результат:</td><td><?=$s ?></td></tr>
		</table>
	</form>
</body>
</html>
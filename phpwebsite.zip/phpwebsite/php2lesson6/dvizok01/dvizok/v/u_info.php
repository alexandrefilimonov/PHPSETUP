<?php
	$user_name = $_SESSION['user_name'];
	$user_login = $_SESSION['user_login'];
	//print_r ($_SESSION);
	echo 'Добро пожаловать, ' . $user_name . '! Ваш логин - ' . $user_login . '.';
?>
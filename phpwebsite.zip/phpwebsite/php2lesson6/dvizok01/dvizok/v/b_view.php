<h3><?php if(isset($text)){echo $text;}?></h3>
<br>
<form method="post">
	<table border=0>
		<tr align="center">
			<td width=120>Количество:</td><td width=140>Изображение товара:</td><td width=200>Название:</td><td width=80>Cумма за единицу товара:</td><td></td>
		</tr>	
		<?php if(isset($basket_text)){echo $basket_text;}?>			
	</table>
	<?php if(isset($basket_total_sum_text)){echo $basket_total_sum_text;}?>
	<input type="submit" name="toorder" value="Сделать заказ и перейти к оплате">
</form>
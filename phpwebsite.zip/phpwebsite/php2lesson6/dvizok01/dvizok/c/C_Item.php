<?php
	include_once 'm/Item.php';
	class C_Item extends C_Base {
		
		public function action_view() {
			$this->title .= '::Просмотр товара';			if (isset($_GET['num'])) {				$item_id = $_GET['num'];				$message = "";				if ($item_id == "0") {					$message = "Товар не выбран для просмотра. Зайдите в каталог и кликните на изображении товара.<br><br>";					$item_text=""; 					$this->content = $this->Template('v/i_view.php', array('message_text' => $message, 'item_text' => $item_text));				}				else {					$new_item = new Item();					$message = "Букет #".$item_id.":<br><br>";					$new_item = new Item();					$item_text='';					$row = $new_item->get_goods_by_id($item_id);					$s='';					if ($row) {						$s='<i>'.$row["name"].'</i><br><br><img alt="Букет #'.$row["id_good"].'" width=205 src="img/'.$row["id_good"].'.jpg" /></a><br><br>'.$row["price"].'.00 руб';						$item_text=$item_text.$s;							}											$this->content = $this->Template('v/i_view.php', array('message_text' => $message, 'item_text' => $item_text));				}			}
		}
			
		public function action_add(){
			$this->title .= '::Добавить в корзину';
		
			if($this->isPost())
			{
				echo "Get exists";
				text_set($_POST['text']);
				header('location: index.php');
				exit();
			}
			$text = text_get();
			$this->content = $this->Template('v/v_add.php', array('text' => $text));		
		}
	}
?>
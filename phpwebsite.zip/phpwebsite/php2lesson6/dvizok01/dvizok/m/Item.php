<?php
	include_once 'config/db.php';

	class Item {		
		public $id_good, $status, $name, $price ;

		public function __construct () {
		}

		public function connecting () {
			return new PDO(DRIVER . ':host='. SERVER . ';dbname=' . DB, USERNAME, PASSWORD);
		}
		
		public function get () {
			$connect = $this->connecting();
			$connection = mysqli_connect("localhost","root","DeltaDental!","world"); 
			return mysqli_query($connection, "SELECT * FROM goods");
		}
		public function get_goods_by_id ($id) {
			$connect = $this->connecting();
			return $connect->query("SELECT * FROM goods WHERE id_good = " . $id . "")->fetch();
		}
	}
?>
<?php
	include_once 'config/db.php';

	class Catalog {		
		public $id_good, $status, $name, $price ;

		public function __construct () {
		}

		public function connecting () {
			return new PDO(DRIVER . ':host='. SERVER . ';dbname=' . DB, USERNAME, PASSWORD);
		}
		
		public function get ($limit) {
			$connect = $this->connecting();
			$connection = mysqli_connect("localhost","root","DeltaDental!","world"); 
			return mysqli_query($connection, "SELECT * FROM goods WHERE id_good>".$limit." LIMIT 4;");
			//return $connect->query("SELECT * FROM goods"); /*->fetch_all(1); fetch(); MYSQLI_NUM*/
		}
		public function getqty () {
			$connect = $this->connecting();
			return $connect->query("SELECT COUNT(*) FROM world.goods WHERE status=1")->fetch();
		}
	}
?>
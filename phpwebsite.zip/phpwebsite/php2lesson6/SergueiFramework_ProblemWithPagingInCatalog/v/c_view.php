<?php 
$p="0";
			/*if (isset($_GET["page"])) {
				$p=1;
				$limit=4*$_GET["page"];
				echo $p."$1";
			}	
			else {
				$p =++$_GET["page"];	
				$limit+=4;
				echo $p."$2";
			}
			<!--&page="<?=$p; ?>-->
			*/
?>
<h3><?php if(isset($text)){echo $text;}?></h3>
<br>
<form method="post">
	<table border=0>
		<tr align="center">
			<td width=120>Номер букета:</td><td width=140>Изображение товара:</td><td width=200>Название:</td><td width=80>Цена:</td><td></td>
		</tr>	
		<?php if(isset($catalog_text)){echo $catalog_text;}?>			
	</table>
	<a class="btnMore" href="index.php?c=catalog&act=view&page="<?php $p="0"; echo $p; ?>>More...</a>
</form>
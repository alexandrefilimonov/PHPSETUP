﻿<?php
//include "configmysql.php";
$connection = mysqli_connect("localhost","root","DeltaDental!","world");

$sql = "select * from images2 where id=7";
$res = mysqli_query($connection,$sql);

include_once "models\config.php";
$bouquetname = ""; 
$description = ""; 

while($data = mysqli_fetch_assoc($res)){
	$bouquetname = $data[bouquetname];
	$description = $data[images_info];
}
?>
<html>
<body><div class="container">
	<div class="header">
		<meta charset="UTF-8">
		<LINK href="css/shop_sell_boucets.css" type="text/css" rel="stylesheet">
		<style>a {text-decoration: none;} </style>
		<ul class="menu">
			<li><a href="Index.html"><img class="logo" src="img/gift.png" /></a></li>		
			<li><a style="text-decoration=none;" href="Index.html" class="menuButton">Главная</a></li>
			<li><a href="Catalog.php" class="menuButton">Каталог букетов</a></li>
			<li><a href="Contacts.php" class="menuButton">Cделать заказ</a></li>
			<li><a href="LoginForm.php" class="menuButton">Войти/Выйти</a></li>			
		</ul>
	</div>
<div class="body">
	<h2><?=$bouquetname ?></h2>
	<div class="flower"><img class="flower_pic" src="img/2.jpg" ></img><br />
		<a href="Contacts.php"><b>Купить</b></a>
		<b>Краткое опиcание композиции:</b><?=$description ?>
		<h3>Характеристики:
		<table class="characteristics">
		<tr><td>Название</td><td>есть</td>
		</tr>
		<tr><td>Цветовая гамма</td><td>есть</td>
		</tr>
		<tr><td>Цветы</td><td>есть</td>
		</tr>
		<tr><td>Количество цветов</td><td>есть</td>
		</tr>
		<tr><td>Дата среза цветов</td><td>нет</td>
		</tr>
		<tr><td>Номер букета</td><td>есть</td>
		</tr>
		<tr><td>Цена</td><td>есть</td>
		</tr>
		</table>
		</h3>
	</div>
	<!--<p>Пол, Цвет, Вид спорта, Материал верха, Покрой, Капюшон, Количество карманов, Длина по спинке, Производитель, Артикул производителя, Цена</i></p>-->
	<h4>Подробное описание:</h4>
	<dl>
	    <dt><b>Название:</b></dt><dd>Букет "С днем рожденья!"</dd>
		<dt><b>Цветовая гамма:</b></dt><dd>Розово-белая</dd>
		<dt><b>Цветы:</b></dt><dd>Лилии, незабудки, ноготки, розы</dd>
		<dt><b>Количество цветов:</b></dt><dd>17</dd>
		<dt><b>Производитель:</b></dt><dd>Оранжерея "Южная", Московская область</dd>
		<dt><b>Номер букета:</b></dt><dd>440A</dd>
		<dt><b>Цена:</b></dt><dd>5 999 руб</dd>
	</dl>
</div>
<div class="footer">
	<div class="shopAddress">
		<ul>
			<li><b>Магазин "Дарите женщинам цветы!":</b></li>
			<li>Телефон:&nbsp;+7&nbsp;(905)&nbsp;456-67-67</li>
			<li>Е-мэйл:&nbsp;magaizinzvetov@magaizinzvetov.ru</li>
			<li>Адрес:&nbsp;119034 г.Москва, ул.Остоженка, д.12/1, строение 3</li>
		</ul>
	</div>
	<div class="shopAddress1">
		<ul>
			<li>Как нас найти?</li>
			<li>
				<a target=_new href="https://yandex.ru/maps/213/moscow/?ll=37.599310%2C55.742336&z=16&mode=search&ol=geo&ouri=ymapsbm1%3A%2F%2Fgeo%3Fll%3D37.599313%252C55.742337%26spn%3D0.001000%252C0.001000%26text%3D%25D0%25A0%25D0%25BE%25D1%2581%25D1%2581%25D0%25B8%25D1%258F%252C%2520%25D0%259C%25D0%25BE%25D1%2581%25D0%25BA%25D0%25B2%25D0%25B0%252C%2520%25D1%2583%25D0%25BB%25D0%25B8%25D1%2586%25D0%25B0%2520%25D0%259E%25D1%2581%25D1%2582%25D0%25BE%25D0%25B6%25D0%25B5%25D0%25BD%25D0%25BA%25D0%25B0%252C%252012%252F1%25D1%25813%2520">
					<img src="img/ShopAddressMap.jpg" height="74px" />
				</a>
			</li>
		</ul>	
	</div>
	<div class="copyright">
		<b>© Все права защищены</b>
	</div>
</div>
</div>
</body>
</html>
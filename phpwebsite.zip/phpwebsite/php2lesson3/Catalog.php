<?php
$msg="";
$connection1 = mysqli_connect("localhost","root","DeltaDental!","world");
$sql = "select * from images";
$n = 5;
$s = ""; 
$res = mysqli_query($connection1,$sql);
while($data = mysqli_fetch_assoc($res)){
	$s = $s . "<div><a class='divCatalogA' href='Item".$data[name].".php?id=".$data[name]."'><img class='catalogItemImage' target=_new src='img/pics/".$data[name].".jpg'></img></a>";
	$s = $s . "<span class='catalogItem'>".$data[images_info]."</span></div>";
}
// формируем массив
$nav = array(
  'primary' => array(
    array('name' => 'Главная', 'url' => 'Index.html', 'cssclassname' => 'menuButton'),
    array('name' => 'Каталог букетов', 'url' => 'Catalog.php', 'cssclassname' => 'menuButton'),
    array('name' => 'Сделать заказ', 'url' => 'Contacts.php', 'cssclassname' => 'menuButton'),
    array('name' => 'Bойти/Выйти', 'url' => 'LoginForm.php', 'cssclassname' => 'menuButton'),
  ),
  'secondary' => array(
    array('images_info' => 'Букет "Подарочный"', 'name' => '1'),
    array('images_info' => 'Букет "С днем рожденья!"', 'name' => '2'),
    array('images_info' => 'Букет "Сюрприз!"', 'name' => '3'),
    array('images_info' => 'Букет "Свадебный-1"', 'name' => '4'),
    array('images_info' => 'Букет "Свадебный-2"', 'name' => '5')
  )
);

include 'Twig/Autoloader.php';
Twig_Autoloader::register();

try {
  $loader = new Twig_Loader_Filesystem('templates');  
  $twig = new Twig_Environment($loader);
  $template = $twig->loadTemplate('shop.tmpl');
  echo $template->render(array (
    'nav' => $nav,
    'updated' => '24 сентября 2018г.'
  ));
  
} catch (Exception $e) {
  die ('ERROR: ' . $e->getMessage());
}
?>
<head>
	<meta charset="UTF-8">
</head>
<?
include "config.php";
$name = $_GET[name];
$price = $_GET[price];
$sql = "insert into shop(name,price) VALUES('$name',$price)";

$res = mysqli_query($connect,$sql);
echo "ADD ".mysqli_affected_rows($connect);

